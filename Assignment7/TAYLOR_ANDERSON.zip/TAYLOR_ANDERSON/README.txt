Author: Anderson Taylor & Trey Howell

Date: 11/19/2018

Assignment 7	CSCI325


Description: A simple linked list implementation of a Library Inventory system.

I ran into a bug when compiled on a linux machine where the while loop to read from the input file would infinite loop. Myself and some of my class mates couldnt figure out a solution to the problem as we had used a while loop with the input stream as the conditional, for some reason no matter how we tried it the loop would never exit.  So as a proof of concept i just repliced the while with a for loop that would read in the first 5 books only from the file. This id just to prove that the rest of the prograsm is functional.



The name of the input file is books.txt.
